package service;

import bean.Employee;

public interface EmployeeService {
	public void addEmployee();
	public void updateEmployee();
	public void deleteEmployee();
	public void findAllEmployee();

}
